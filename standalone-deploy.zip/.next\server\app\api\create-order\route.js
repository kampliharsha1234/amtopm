var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/create-order/route.js")
R.c("server/chunks/[externals]__1dnnclq._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/[root-of-the-server]__1r-dbq1._.js")
R.c("server/chunks/[root-of-the-server]__00_hq9v._.js")
R.c("server/chunks/_next-internal_server_app_api_create-order_route_actions_0bel4f_.js")
R.m(22720)
module.exports=R.m(22720).exports
