var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[externals]__0xg9g94._.js")
R.c("server/chunks/lib_users_ts_15r1bg_._.js")
R.c("server/chunks/[root-of-the-server]__00_hq9v._.js")
R.c("server/chunks/_1f1af6x._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_[___nextauth]_route_actions_08nexdk.js")
R.m(59061)
module.exports=R.m(59061).exports
