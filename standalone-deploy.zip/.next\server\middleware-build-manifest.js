globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/AzQR6r0NGmduzzlHRGu3I/_buildManifest.js",
    "static/AzQR6r0NGmduzzlHRGu3I/_ssgManifest.js",
    "static/AzQR6r0NGmduzzlHRGu3I/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/33g_4yfdp1_l_.js",
    "static/chunks/2ahsrb9i7ar11.js",
    "static/chunks/43k_6-iw24653.js",
    "static/chunks/turbopack-05u8ke_0tphnr.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
