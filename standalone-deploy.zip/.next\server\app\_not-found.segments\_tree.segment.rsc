:HL["/_next/static/chunks/14bxl_qy4692x.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4180,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"AzQR6r0NGmduzzlHRGu3I"}
