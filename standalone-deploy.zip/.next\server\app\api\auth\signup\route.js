var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/signup/route.js")
R.c("server/chunks/[root-of-the-server]__0-1lx5s._.js")
R.c("server/chunks/lib_users_ts_15r1bg_._.js")
R.c("server/chunks/[root-of-the-server]__00_hq9v._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_signup_route_actions_0iddpqa.js")
R.m(1064)
module.exports=R.m(1064).exports
